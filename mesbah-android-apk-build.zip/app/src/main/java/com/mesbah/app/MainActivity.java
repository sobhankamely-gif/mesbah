package com.mesbah.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.ComponentName;
import android.content.pm.PackageManager;

public class MainActivity extends Activity {
    private WebView webView;
    private final String[] aliases = {
        "LauncherDefault", "LauncherSpring", "LauncherYalda", "LauncherMehregan",
        "LauncherChaharshanbe", "LauncherMourning", "LauncherReligious", "LauncherFatemiyeh"
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new MesbahNative(), "MesbahNative");
        webView.loadUrl("https://sobhankamely-gif.github.io/mesbah/");
    }

    private class MesbahNative {
        @JavascriptInterface public void setIcon(String theme) {
            runOnUiThread(() -> {
                String wanted;
                switch (theme == null ? "default" : theme) {
                    case "e": wanted = "LauncherSpring"; break;
                    case "y": wanted = "LauncherYalda"; break;
                    case "h": wanted = "LauncherMehregan"; break;
                    case "c": wanted = "LauncherChaharshanbe"; break;
                    case "m": wanted = "LauncherMourning"; break;
                    case "r": wanted = "LauncherReligious"; break;
                    case "f": wanted = "LauncherFatemiyeh"; break;
                    default: wanted = "LauncherDefault";
                }
                PackageManager pm = getPackageManager();
                for (String alias : aliases) {
                    ComponentName cn = new ComponentName(MainActivity.this, "com.mesbah.app." + alias);
                    int state = alias.equals(wanted) ? PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                                                     : PackageManager.COMPONENT_ENABLED_STATE_DISABLED;
                    pm.setComponentEnabledSetting(cn, state, PackageManager.DONT_KILL_APP);
                }
            });
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
